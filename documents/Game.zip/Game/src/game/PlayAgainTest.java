/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Craig's
 */
public class PlayAgainTest {
    public static void main(String [] args){
    PlayAgain play = new PlayAgain();
    String choice;
    //choice = play.playagain("");
    
    }
}
