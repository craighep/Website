/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author Craig's
 */
public class LevelTest {
    public static void main(String [] args){
      LevelChoice level = new LevelChoice(); 
      System.out.println("How Many Levels Would You Like To Play? 1/2 test");
      String levelchoice = "Invalid level input!";
      //levelchoice = level.levelChoice();
      System.out.println(levelchoice);
      
    }
}
