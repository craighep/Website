package Data;



public class Data {
public static String name = "&5"; //craighep
public static String pass = "#_@C"; //f1f2f3
public static boolean b;

public boolean checkName(String namen, String passn) {
	CEncrypt en = new CEncrypt();
	
    if (name.equals(en.en(namen)) & (pass.equals(en.en(passn)))){b = true;
}
    else {b = false;}
    
    return b;
}
public String getCustomer(){
	return name;
}


}
