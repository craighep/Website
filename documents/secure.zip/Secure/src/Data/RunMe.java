package Data;

import GUI.Frame;

public class RunMe {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Frame fr = new Frame();
		fr.gameFrame();
	}

}
