
package GUI;

/**
 *
 * @author Craig Heptinstall(Crh13)
 */
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;

import Data.Data;


/**
 * The Class LoadFrame.
 * This class opens a frame displaying a list of possible loads, then allows the
 * user to select one, getting this and sending it to the @FileIO class.
 * 
 */
public class Frame extends JFrame  {
	
    
    /** The Load frame. */
    /** The load p. */
    JPanel gameP = new JPanel();
    JPanel game = new JPanel();
    
    /** The cancel. */
    private JButton  ok, exit, logOut;
    
    
    
    private JLabel empty1, empty2, user, pass;
    
    /** The name. */
    public static JTextField name;
    public static JPasswordField password;
    
    /** The Constant RIGHT_TO_LEFT. */
    final static boolean RIGHT_TO_LEFT = false;
    
    /** The Constant shouldFill. */
    final static boolean shouldFill = true;
    
    /** The Constant shouldWeightX. */
    final static boolean shouldWeightX = true;
    
    private JMenuBar mb = new JMenuBar();
    /**
     * The file menu.
     */
    private JMenu fileMenu = new JMenu("File");
    private static JLabel test;
    /**
	 * The edit menu.
	 */
	
	public void gameFrame() {
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setTitle("Login");
	    this.setLocationRelativeTo(null);
	    gamePanel();
	    Border raisedbevel;
		raisedbevel = BorderFactory.createRaisedBevelBorder();
		gameP.setBorder(raisedbevel);
	    this.add(game);
	    this.add(gameP);     
	    this.setJMenuBar(mb);
	    test = new JLabel("To Begin, Please Log In...");
	    Font font = new Font("Serif", Font.PLAIN, 15);
	    test.setFont(font);
	    mb.add(test);
	    this.pack();
	    showIt();
	
	}

    /**
     * Load panel.
     */
    public void gamePanel() {
    	
        this.setBackground(Color.gray);
        this.setPreferredSize(new Dimension(500, 500)); //Set size of panel
        initComponents();
        setLayout();
        setLayoutIn();

        
   }

    /**
     * initializes the components.
     */
    public void initComponents() {
        
    	Border raisedbevel;
    	raisedbevel = BorderFactory.createRaisedBevelBorder();
    	
        
       empty1 = new JLabel("");
       empty2 = new JLabel("");
       user = new JLabel("User: ");
       pass = new JLabel("Pass: ");
       

    	name = new JTextField("");
    	password = new JPasswordField("");
    	name.setBorder(raisedbevel);
    	password.setBorder(raisedbevel);

    	
    	name.setHorizontalAlignment(JTextField.CENTER);
    	password.setHorizontalAlignment(JTextField.CENTER);
    	user.setHorizontalAlignment(JTextField.RIGHT);
    	pass.setHorizontalAlignment(JTextField.RIGHT);

 		Font font = new Font("Serif", Font.BOLD, 24);
    	name.setFont(font);
    	password.setFont(font);
        ok = new JButton("OK");
        ok.addActionListener(new ActionListener() {  
            @Override
            public void actionPerformed(ActionEvent e)
            {
               
         	   Data data = new Data();
         	   
          	  if (data.checkName(name.getText(),password.getText()) == true){
            	mb.removeAll();
              	test.setText("Welcome Back!");
                mb.add(test);
            	gameP.setVisible(false);
            	game.setVisible(true);
            //	}
         	   
                
            }});
               
        exit = new JButton("Cancel");
        exit.addActionListener(new ActionListener() {  
            @Override
            public void actionPerformed(ActionEvent e)
            {
              System.exit(0);
            }});
            logOut = new JButton("Log Out");
            logOut.addActionListener(new ActionListener() {  
                @Override
                public void actionPerformed(ActionEvent e)
                {
                  System.exit(0);
                }
        });
        
       
        
        
}
    
/**
 * Sets the layout.
 */
public void setLayout() {
        if (RIGHT_TO_LEFT) {
            gameP.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        }
        gameP.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        if (shouldFill) {
            //natural height, maximum width
            c.fill = GridBagConstraints.HORIZONTAL;
        }

        if (shouldWeightX) {
            c.weightx = 0.5;
        }
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 55; 
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 1;
        gameP.add(user, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 55; 
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 1;
        gameP.add(pass, c);
       
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 55; 
        c.gridx = 1;
        c.gridy = 4;
        c.gridwidth = 1;
        gameP.add(empty1, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 55; 
        c.gridx = 4;
        c.gridy = 4;
        c.gridwidth = 1;
        gameP.add(empty2, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 55; 
        c.gridx = 2;
        c.gridy = 4;
        c.gridwidth = 1;
        gameP.add(ok, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 55; 
        c.gridx = 3;
        c.gridy = 4;
        c.gridwidth = 1;
        gameP.add(exit, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 30; 
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 2;
        gameP.add(name, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 30; 
        c.gridx = 2;
        c.gridy = 3;
        c.gridwidth = 2;
        gameP.add(password, c);
        
               
    }

public void setLayoutIn() {
    if (RIGHT_TO_LEFT) {
        game.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
    }
    game.setLayout(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    if (shouldFill) {
        //natural height, maximum width
        c.fill = GridBagConstraints.HORIZONTAL;
    }

    if (shouldWeightX) {
        c.weightx = 0.5;
    }
    c.fill = GridBagConstraints.HORIZONTAL;
    c.ipady = 55; 
    c.gridx = 1;
    c.gridy = 1;
    c.gridwidth = 1;
    game.add(logOut, c);}
    
    
    
 
    /**
     * Show it.
     */
    public void showIt() {
        //Display frame on screen
        this.setVisible(true);
    }
   
		}
	
    

