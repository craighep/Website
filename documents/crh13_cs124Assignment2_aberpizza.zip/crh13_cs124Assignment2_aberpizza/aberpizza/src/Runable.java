
import uk.ac.aber.dcs.cs12420.aberpizza.panel.SplashScreen1;





/**
 * Launcher for program. Contains the main method
 * that loads the main JFrame for the program (TillFrame)
 * 
 * @author Craig Heptinstall (crh13)
 *
 */
public class Runable {
    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
                               
               SplashScreen1 ss = new SplashScreen1();
                ss.SplashScreen();
        	
	}
}
