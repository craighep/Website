package types;

import java.util.Calendar;

public class Stats implements iStats
{
	private Calendar  m_Start;
	public Calendar   m_Finish;
	public int 		  m_Sorts;
	private String    m_Name;
	private Integer[] m_OriginalData;
	
	@Override
	public void setStartCal(Calendar cal) {
		m_Start = cal;
	}
	@Override
	public Calendar getStartCal() {
		return m_Start;
	}
	//--------------------------------------------------------------------------
	@Override
	public void setFinishCal(Calendar cal)
	{
		m_Finish = cal;
	}
	@Override
	public Calendar getFinishCal()
	{
		return m_Finish;
	}
	//--------------------------------------------------------------------------
	@Override
	public void setSortAmount(int sorts)
	{
		m_Sorts = sorts;
	}
	@Override
	public int getSortAmount()
	{
		return m_Sorts;
	}
	//--------------------------------------------------------------------------
	@Override
	public void setSortName(String name)
	{
		m_Name = name;
	}
	@Override
	public String getSortName()
	{
		return m_Name;
	}
	//--------------------------------------------------------------------------
	@Override
	public void setOriginalData(Integer[] toBeSortedArr) 
	{
		m_OriginalData = toBeSortedArr;
	}
	@Override
	public Integer[] getOriginalData()
	{
		return m_OriginalData;
	}
	//--------------------------------------------------------------------------
	
}
