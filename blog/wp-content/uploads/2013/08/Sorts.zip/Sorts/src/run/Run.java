package run;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

import sorts.BogoSort;
import sorts.BubbleSort;
import sorts.BucketSort;
import sorts.HeapSort;
import sorts.InsertionSort;
import sorts.MergeSort;
import sorts.QuickSort;
import sorts.RadixSort;
import sorts.ShellSort;
import types.Stats;
import data.PrintStats;
import data.ReadData;

public class Run {

	public static String currentFile = null;

	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException 
	{
		System.out.println("\n|-----------------------------|");
		System.out.println("|   Multiple Sorter Program   |");
		System.out.println("|    - Craig Heptinstall -    |");
		System.out.println("|-----------------------------|");
		System.out.println("\n");
		System.out.println("Hints*");
		System.out.println("- File containing unsorted data can be");
		System.out.println(" seperted using spaces, commas, both or line breaks.");
		System.out.println("- Bogosort takes almost forver, use with caution.");
		System.out.println("\n\n\n");
		
		@SuppressWarnings("resource")
		Scanner reader = new Scanner(System.in);
		ReadData toSort = new ReadData();
		ArrayList<Integer> toBeSorted = toSort.getToBeSorted(currentFile);
		Stats stats = new Stats();
    	Integer[] toBeSortedArr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
		PrintStats outStats = new PrintStats();
		Calendar start = Calendar.getInstance();
		
		while ( true )
		{
			System.out.println("\nChoose an option: ");
			System.out.println("1 - Merge sort");
			System.out.println("2 - Bubble sort");
			System.out.println("3 - Quick sort");
			System.out.println("4 - Shell Sort");
			System.out.println("5 - Heap Sort");
			System.out.println("6 - Radix Sort");
			System.out.println("7 - Insertion Sort");
			System.out.println("8 - Bucket Sort");
			System.out.println("9 - Bogosort");
			System.out.println("--------------------------");
			System.out.println("10 - Re-Input file");
			System.out.println("11 - Re-Load current file");
			//----------------------------------
			System.out.println("0 - Quit");
		
			String choice = reader.next();
			try 
			{
				int selection = Integer.parseInt(choice);
				
				switch( selection )
				{
				case 1:
					start = Calendar.getInstance();
					MergeSort mergeSort = new MergeSort();
			    	Integer[] arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = mergeSort.mergeSort(arr);
					stats.setOriginalData(toBeSortedArr);
					MergeSort.sorts = 0;
					stats.setStartCal(start);
					stats.setSortName("Merge Sort");
					outStats.printStats(stats);
					break;
				
				case 2:
					start = Calendar.getInstance();
					BubbleSort bubbleSort = new BubbleSort();
					stats = bubbleSort.bubbleSort(toBeSorted);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Bubble Sort");
					outStats.printStats(stats);
					break;
					
				case 3:
					start = Calendar.getInstance();
					QuickSort quickSort = new QuickSort();
			    	arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = quickSort.quickSort(arr, 0, arr.length-1);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Quick Sort");
					outStats.printStats(stats);
					break;
					
				case 4:
					start = Calendar.getInstance();
					ShellSort shellSort = new ShellSort();
					arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = shellSort.shellSort(arr);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Shell Sort");
					outStats.printStats(stats);
					break;
				
				case 5:
					start = Calendar.getInstance();
					HeapSort heapSort = new HeapSort();
					arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = heapSort.sort(arr);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Heap Sort");
					outStats.printStats(stats);
					break;
					
				case 6:
					start = Calendar.getInstance();
					RadixSort radixSort = new RadixSort();
					arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = radixSort.radixSort(arr);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Radix Sort");
					outStats.printStats(stats);
					break;
					
				case 7:
					start = Calendar.getInstance();
					InsertionSort insertionSort = new InsertionSort();
					arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = insertionSort.insertionSort(arr);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Insertion Sort");
					outStats.printStats(stats);
					break;
					
				case 8:
					start = Calendar.getInstance();
					BucketSort bucketSort = new BucketSort();
					arr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					stats = bucketSort.bucketSort(arr);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Bucket Sort");
					outStats.printStats(stats);
					break;
					
				case 9:
					start = Calendar.getInstance();
					BogoSort bogoSort = new BogoSort();
					stats = bogoSort.bogoSort(toBeSorted);
					stats.setOriginalData(toBeSortedArr);
					stats.setStartCal(start);
					stats.setSortName("Bogosort");
					outStats.printStats(stats);
					break;
					
				case 10:
					toBeSorted = toSort.getToBeSorted(currentFile);
					stats = new Stats();
			    	toBeSortedArr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					break;
					
				case 11:
					toBeSorted = toSort.getToBeSorted(currentFile);
					stats = new Stats();
			    	toBeSortedArr = toBeSorted.toArray(new Integer[toBeSorted.size()]);
					break;
					
				case 0:
					System.out.println("\nSystem Exited.");
					System.exit(0);
					
				default: System.out.println("Invalid Selection\n");
				}
				System.out.println("\n\n\n\n");
			}
			catch (Exception e)
			{
				System.out.println("Invalid Selection\n");
			}
			
		}
	}

}
