package data;

import java.util.Scanner;

import types.Stats;

public class PrintStats 
{
	public void printStats(Stats stats) 
	{
		System.out.println("--------------------------------------");
		System.out.print("Original data: ");
		for(int b = 0; b < stats.getOriginalData().length; b++)
        {
        System.out.print(stats.getOriginalData()[b]);
        if ( stats.getOriginalData().length - 1 != b )
        	System.out.print(",");
        }
		System.out.print("\n");
		
		System.out.println("Sort: " + stats.getSortName());
		System.out.println("--------------------------------------");
		System.out.println("Number of sorts: " + stats.getSortAmount());

		long startMili = stats.getStartCal().getTimeInMillis();
		long completeMili = stats.getFinishCal().getTimeInMillis();
		long timeMili = completeMili - startMili;

		if (timeMili < 1000) 
		{
			System.out.println("Total time: " + timeMili
					+ " milliseconds. \n\n");
		}
		else if (timeMili < 60000) 
		{
			double timeSeco = (double) timeMili / 1000;
			System.out.println("Total time: " + timeSeco + " seconds. \n\n");
		}
		else 
		{
			int timeSeco = (int) ((timeMili / 1000) % 60);
			int timeMinu = (int) ((timeMili / 1000) / 60);
			System.out.println("Total time: " + timeMinu + " minutes "
					+ timeSeco + " seconds. ");
		}
		
		System.out.println("================================\nPress enter to continue...");
		@SuppressWarnings("resource")
		Scanner keyIn = new Scanner(System.in);
		keyIn.nextLine();
		System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n");
	}
}
