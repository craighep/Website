package sorts;

import java.util.Calendar;

import types.Stats;

public class BucketSort
{

	public Stats bucketSort(Integer[] array)
	{
	  int sorts = 0;
	  int N = array.length;
	  int min = array[0];
	  int max = min;
	  for( int i = 1; i < N; i++ )              
	    if( array[i] > max )
	      max = array[i];
	    else if( array[i] < min )
	      min = array[i];
	
	  int bucket[] = new int[max-min+1];         
	  
	  for( int i = 0; i < N; i++ )              
	    bucket[array[i]-min]++;                  
	
	  int i = 0;                                  
	  for( int b = 0; b < bucket.length; b++ )    
	    for( int j = 0; j < bucket[b]; j++ )     {
	      array[i++] = b+min;        
	      sorts++;
	    }
	  
	  Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
      System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

		System.out.print(" Sorted: ");
      for(int b = 0; b < array.length; b++)
      {
      System.out.print(array[b]);
      if ( array.length - 1 != b )
      	System.out.print(",");
      }
      System.out.print("\n\n");
		
		return stats;
	 }
}