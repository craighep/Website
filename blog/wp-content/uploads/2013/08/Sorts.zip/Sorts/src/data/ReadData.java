package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import run.Run;

public class ReadData {
	
	public ArrayList<Integer> getToBeSorted(String file) throws IOException 
	{
		ArrayList<Integer> before = new ArrayList<Integer>();
		String choice = "";
		
		if ( file == null ){
		System.out.println("Enter file containing unsorted list: ");
		}
		boolean legal = false;
		while (legal == false)
		{
			if( file != null )
			{
			 choice = file;
			}
			else
			{
			@SuppressWarnings("resource")
			Scanner reader = new Scanner(System.in);
			 choice = reader.next();
			}
			
		if ( choice != null )
			legal = true;
		
		if ( legal == true )
		{
			try {
			BufferedReader br = new BufferedReader(new FileReader(choice));
		        StringBuilder sb = new StringBuilder();
		        String line = br.readLine();
		        if ( line == null || line.equals("") ){
		        	legal = false;
		        	System.out.println("Invalid file, try again: ");
		        }
	
		        while (line != null) 
		        {
		            sb.append(line);
		            sb.append('\n');
		            String lineRead = line.toString();
		            if ( lineRead.contains(", ") )
		            {
		            	for (int i = 0; i < lineRead.length();){
		            		if ( lineRead.contains(", ") )
		            		{
		            		String read = lineRead.substring(i, lineRead.indexOf(", "));
		            		i = read.length() + 2;
		            		lineRead = lineRead.substring(i, lineRead.length());
		            		i = 0;
		            		before.add(Integer.parseInt(read));
		            		}
		            		else 
		            		{
		            		before.add(Integer.parseInt(lineRead));
		            		i = lineRead.length();
		            		}
		            	}
		            	line = br.readLine();
		            }
		            else if ( lineRead.contains(",") )
		            {
		            	for (int i = 0; i < lineRead.length();){
		            		if ( lineRead.contains(",") )
		            		{
		            		String read = lineRead.substring(i, lineRead.indexOf(","));
		            		i = read.length() + 1;
		            		lineRead = lineRead.substring(i, lineRead.length());
		            		i = 0;
		            		before.add(Integer.parseInt(read));
		            		}
		            		else 
		            		{
		            		before.add(Integer.parseInt(lineRead));
		            		i = lineRead.length();
		            		}
		            	}
		            	line = br.readLine();
		            }
		            else if ( lineRead.contains(" ") )
		            {
		            	for (int i = 0; i < lineRead.length();){
		            		if ( lineRead.contains(" ") )
		            		{
		            		String read = lineRead.substring(i, lineRead.indexOf(" "));
		            		i = read.length() + 1;
		            		lineRead = lineRead.substring(i, lineRead.length());
		            		i = 0;
		            		before.add(Integer.parseInt(read));
		            		}
		            		else 
		            		{
		            		before.add(Integer.parseInt(lineRead));
		            		i = lineRead.length();
		            		}
		            	}
		            	line = br.readLine();
		            }
		            else 
		            {
		            before.add(Integer.parseInt(lineRead));
		            line = br.readLine();
		            }
		        }
		        br.close();
		    } 
		    catch (Exception e)
		    {
		    	file = null;
		    	legal = false;
		    	System.out.println(e);
	        	System.out.println("Invalid file, try again: ");
		    }
		}
		}
		Run.currentFile = choice;
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		return before;
	}
}
