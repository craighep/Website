package sorts;
import java.util.ArrayList;
import java.util.Calendar;

import types.Stats;

public class BubbleSort 
{
    public Stats bubbleSort(ArrayList<Integer> before)
    {
    	Integer[] arr = before.toArray(new Integer[before.size()]);
    	int temp;
    	int sorts = 0;
        for(int i=0; i < arr.length-1; i++)
        {
 
            for(int j=1; j < arr.length-i; j++)
            {
                if(arr[j-1] > arr[j])
                {
                    temp=arr[j-1];
                    arr[j-1] = arr[j];
                    arr[j] = temp;
                }
                sorts++;
//                System.out.print(" Sort No. "+ sorts + " = ");
//                for(int b = 0; b < arr.length; b++)
//                {
//                System.out.print(arr[b]);
//                if ( arr.length - 1 != b )
//                	System.out.print(",");
//                }
//                System.out.print("\n\n");
            }
            
        }
        
        Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

		System.out.print(" Sorted: ");
        for(int b = 0; b < arr.length; b++)
        {
        System.out.print(arr[b]);
        if ( arr.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
		
        return stats;
    }
}