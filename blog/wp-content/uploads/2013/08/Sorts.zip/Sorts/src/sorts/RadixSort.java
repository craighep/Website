package sorts;

import java.util.Calendar;

import types.Stats;

public class RadixSort{

    public static Stats radixSort(Integer[] arr4){
    	int sorts = 0;
        int[][] np = new int[arr4.length][2];
        int[] q = new int[0x100];
        int i,j,k,l,f = 0;
        for(k=0;k<4;k++){
            for(i=0;i<(np.length-1);i++)
                np[i][1] = i+1;
            np[i][1] = -1;
            for(i=0;i<q.length;i++)
                q[i] = -1;
            for(f=i=0;i<arr4.length;i++){
                j = ((0xFF<<(k<<3))&arr4[i])>>(k<<3);
                if(q[j] == -1)
                    l = q[j] = f;
                else{
                    l = q[j];
                    while(np[l][1] != -1)
                        l = np[l][1];
                    np[l][1] = f;
                    l = np[l][1];
                }
                f = np[f][1];
                np[l][0] = arr4[i];
                np[l][1] = -1;
                
                sorts++;
//    			System.out.print(" Sort No. "+ sorts + " = ");
//    	        for(int b = 0; b < arr4.length; b++)
//    	        {
//    	        System.out.print(arr4[b]);
//    	        if ( arr4.length - 1 != b )
//    	        	System.out.print(",");
//    	        }
//    	        System.out.print("\n\n");
            }
            for(l=q[i=j=0];i<0x100;i++)
                for(l=q[i];l!=-1;l=np[l][1])
                        arr4[j++] = np[l][0];
            
        }
        
        Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

		System.out.print(" Sorted: ");
        for(int b = 0; b < arr4.length; b++)
        {
        System.out.print(arr4[b]);
        if ( arr4.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
		
		return stats;
    }
}