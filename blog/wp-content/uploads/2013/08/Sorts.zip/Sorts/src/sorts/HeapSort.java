package sorts;

import java.util.Calendar;

import types.Stats;

public class HeapSort 
{
    private static Integer[] a;
    private static int n;
    private static int left;
    private static int right;
    private static int largest;

    
    public static void buildheap(Integer[] a2){
        n=a2.length-1;
        for(int i=n/2;i>=0;i--){
            maxheap(a2,i);
        }
    }
    
    public static void maxheap(Integer[] a2, int i){ 
        left=2*i;
        right=2*i+1;
        if(left <= n && a2[left] > a2[i]){
            largest=left;
        }
        else{
            largest=i;
        }
        
        if(right <= n && a2[right] > a2[largest]){
            largest=right;
        }
        if(largest!=i){
            exchange(i,largest);
            maxheap(a2, largest);
        }
    }
    
    public static void exchange(int i, int j){
        int t=a[i];
        a[i]=a[j];
        a[j]=t; 
        }
    
    public Stats sort(Integer []a0){
        a=a0;
        buildheap(a);
        int sorts = 0;
        
        for(int i=n;i>0;i--){
            exchange(0, i);
            n=n-1;
            maxheap(a, 0);
            
            sorts++;
//			System.out.print(" Sort No. "+ sorts + " = ");
//	        for(int b = 0; b < a.length; b++)
//	        {
//	        System.out.print(a[b]);
//	        if ( a.length - 1 != b )
//	        	System.out.print(",");
//	        }
//	        System.out.print("\n\n");
        }
        Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
		
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		System.out.print(" Sorted: ");
        for(int b = 0; b < a.length; b++)
        {
        System.out.print(a[b]);
        if ( a.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
		
		return stats;
    }
}