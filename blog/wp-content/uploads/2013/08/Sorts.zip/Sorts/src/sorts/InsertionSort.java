package sorts;

import java.util.Calendar;

import types.Stats;

public class InsertionSort
 {
	public Stats insertionSort(Integer[] arr)
	{
		int sorts = 0;
		int num=arr.length, i, j, t = 0;
		for (i = 0; i < num; i++) 
		{
			t = arr[i];
			for (j = i - 1; j >= 0 && t < arr[j]; j--) 
			{
				arr[j + 1] = arr[j];
				sorts++;
			}
			arr[j + 1] = t;
		}
		System.out.println("Sorted Array");
		for (i = 0; i < num; i++) {
			System.out.println(arr[i] + " ");
		}
		    Stats stats = new Stats();
			Calendar complete = Calendar.getInstance();
			stats.setFinishCal(complete);
			stats.setSortAmount(sorts);
	        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

			System.out.print(" Sorted: ");
	        for(int b = 0; b < arr.length; b++)
	        {
	        System.out.print(arr[b]);
	        if ( arr.length - 1 != b )
	        	System.out.print(",");
	        }
	        System.out.print("\n\n");
			
	        return stats;
	}
}