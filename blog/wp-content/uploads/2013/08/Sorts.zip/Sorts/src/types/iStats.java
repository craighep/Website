package types;

import java.util.Calendar;

public interface iStats
{
	public void setStartCal(Calendar cal);
	public Calendar getStartCal();
	//--------------------------------------------------------------------------
	public void setFinishCal(Calendar cal);
	public Calendar getFinishCal();
	//--------------------------------------------------------------------------
	public void setSortAmount(int sorts);
	public int getSortAmount();
	//--------------------------------------------------------------------------
	void setSortName(String name);
	String getSortName();
	//--------------------------------------------------------------------------
	void setOriginalData(Integer[] toBeSortedArr);
	Integer[] getOriginalData();
	//--------------------------------------------------------------------------
}
