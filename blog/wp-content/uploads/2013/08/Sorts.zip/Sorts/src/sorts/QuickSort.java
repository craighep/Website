package sorts;

import java.util.Calendar;

import types.Stats;

public class QuickSort {
	private int sorts = 0;
	
	public Stats quickSort(Integer[] arr, int si, int ei){
		
		Stats stats = new Stats();
		
		quickSortGo(arr, si, ei,stats);
		
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

		System.out.print(" Sorted: ");
        for(int b = 0; b < arr.length; b++)
        {
        System.out.print(arr[b]);
        if ( arr.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
		return stats;
	}
	
	public Stats quickSortGo(Integer[] arr, int si, int ei, Stats stats)
	{
	    //base case
	    if(ei<=si || si>=ei)
	    {
	    	
	    }
	    
	    else
	    { 
	        int pivot = arr[si]; 
	        int i = si+1; int tmp; 

	        //partition array 
	        for(int j = si+1; j<= ei; j++)
	        {
	            if(pivot > arr[j])
	            {
	                tmp = arr[j]; 
	                arr[j] = arr[i]; 
	                arr[i] = tmp; 

	                i++; 
	            }
	        }

	        //put pivot in right position
	        arr[si] = arr[i-1]; 
	        arr[i-1] = pivot; 
	        
	        //call qsort on right and left sides of pivot
	        quickSortGo(arr, si, i-2, stats);
	        
	        sorts++;
//			System.out.print(" Sort No. "+ sorts + " = ");
//	        for(int b = 0; b < arr.length; b++)
//	        {
//	        System.out.print(arr[b]);
//	        if ( arr.length - 1 != b )
//	        	System.out.print(",");
//	        }
//	        System.out.print("\n\n");
	        
	        quickSortGo(arr, i, ei, stats); 
	        
	        sorts++;
//			System.out.print(" Sort No. "+ sorts + " = ");
//	        for(int b = 0; b < arr.length; b++)
//	        {
//	        System.out.print(arr[b]);
//	        if ( arr.length - 1 != b )
//	        	System.out.print(",");
//	        }
//	        System.out.print("\n\n");
	    }
	    
	    
		return stats;
	}
}
