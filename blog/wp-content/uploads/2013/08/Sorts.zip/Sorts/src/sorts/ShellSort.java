package sorts;

import java.util.Calendar;

import types.Stats;

public class ShellSort 
{
	public static Stats shellSort(Integer[] a) 
	{
		int sorts = 0;
		int increment = a.length / 2;
		while (increment > 0) {
			for (int i = increment; i < a.length; i++) 
			{
				int j = i;
				int temp = a[i];
				while (j >= increment && a[j - increment] > temp) 
				{
					a[j] = a[j - increment];
					j = j - increment;
					sorts++;
				}
				a[j] = temp;
			}
			if (increment == 2) 
			{
				increment = 1;
			} else 
			{
				increment *= (5.0 / 11);
			}
		}
		Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
		
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		System.out.print(" Sorted: ");
        for(int b = 0; b < a.length; b++)
        {
        System.out.print(a[b]);
        if ( a.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
		
		return stats;
	}
}
