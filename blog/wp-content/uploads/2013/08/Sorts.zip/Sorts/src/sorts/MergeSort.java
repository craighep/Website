package sorts;

import java.util.Arrays;
import java.util.Calendar;

import types.Stats;

public class MergeSort 
{
	
public static int  sorts = 0;

	public Stats mergeSort(Integer[] arr) 
	{
		Stats stats = new Stats();
		stats = mergeSortGo(arr, stats);
		
		System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        System.out.print(" Sorted: ");
        for(int b = 0; b < arr.length; b++)
        {
        System.out.print(arr[b]);
        if ( arr.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
        return stats;
	}

	public Stats mergeSortGo(Integer[] arr, Stats stats) 
	{
        if (arr.length > 1) {
            int q = arr.length/2;

            Integer[] leftArray = Arrays.copyOfRange(arr, 0, q);
            Integer[] rightArray = Arrays.copyOfRange(arr,q,arr.length);

            mergeSortGo(leftArray, stats);
            mergeSortGo(rightArray, stats);

            stats = merge(arr,leftArray,rightArray);
        }
        
        
        return stats;
    }

    static Stats merge(Integer[] arr, Integer[] leftArray, Integer[] rightArray)
    {
        int totElem = leftArray.length + rightArray.length;
        //int[] a = new int[totElem];
        int i,li,ri;
        i = li = ri = 0;
        
        while ( i < totElem)
        {
            if ((li < leftArray.length) && (ri<rightArray.length))
            {
                if (leftArray[li] < rightArray[ri]) {
                    arr[i] = leftArray[li];
                    i++;
                    li++;
                    sorts++;
//            		System.out.print(" Sort No. "+ sorts + " = ");
//                    for(int b = 0; b < arr.length; b++)
//                    {
//                    System.out.print(arr[b]);
//                    if ( arr.length - 1 != b )
//                    	System.out.print(",");
//                    }
//                    System.out.print("\n\n");
                }
                else
                {
                    arr[i] = rightArray[ri];
                    i++;
                    ri++;
                    sorts++;
//            		System.out.print(" Sort No. "+ sorts + " = ");
//                    for(int b = 0; b < arr.length; b++)
//                    {
//                    System.out.print(arr[b]);
//                    if ( arr.length - 1 != b )
//                    	System.out.print(",");
//                    }
//                    System.out.print("\n\n");
                }
            }
            else 
            {
                if (li >= leftArray.length) 
                {
                    while (ri < rightArray.length) 
                    {
                        arr[i] = rightArray[ri];
                        i++;
                        ri++;
                        
                        sorts++;
//                		System.out.print(" Sort No. "+ sorts + " = ");
//                        for(int b = 0; b < arr.length; b++)
//                        {
//                        System.out.print(arr[b]);
//                        if ( arr.length - 1 != b )
//                        	System.out.print(",");
//                        }
//                        System.out.print("\n\n");
                    }
                }
                if (ri >= rightArray.length)
                {
                    while (li < leftArray.length)
                    {
                        arr[i] = leftArray[li];
                        li++;
                        i++;
                        sorts++;
//                		System.out.print(" Sort No. "+ sorts + " = ");
//                        for(int b = 0; b < arr.length; b++)
//                        {
//                        System.out.print(arr[b]);
//                        if ( arr.length - 1 != b )
//                        	System.out.print(",");
//                        }
//                        System.out.print("\n\n");
                    }
                }
            }
        }
        
        Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
		
		return stats;
    }
}
