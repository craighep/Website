package sorts;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import types.Stats;

public class BogoSort 
{
	public Stats bogoSort(ArrayList<Integer> before) 
	{
		ArrayList<Integer> copy = new ArrayList<Integer>(before);
		int[] result = new int[before.size()];

		boolean check = false;
		int sorts = 0;
		while (check != true)
		{
//			sorts++;
//			System.out.print(" Sort No. "+ sorts + " = " );
//			sorts--;
			for (int count = 0; count < result.length; count++)
			{
				int item = new Random().nextInt(copy.size());
				result[count] = copy.get(item);
				copy.remove(item);
//				System.out.print(result[count]);
//				if ( copy.size() > 0 )
//					System.out.print(",");
			}
//			System.out.println("\n");
			copy = new ArrayList<Integer>(before);
			
			int checkMax = -1;
			for (int i = 0; i < result.length; i++) 
			{
				if (result[i] < checkMax) {
					check = false;
					break;
				}
				checkMax = result[i];
				check = true;
			}
			sorts++;
		}
        System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

		System.out.print(" Sorted: ");
        for(int b = 0; b < result.length; b++)
        {
        System.out.print(result[b]);
        if ( result.length - 1 != b )
        	System.out.print(",");
        }
        System.out.print("\n\n");
        
		Stats stats = new Stats();
		Calendar complete = Calendar.getInstance();
		stats.setFinishCal(complete);
		stats.setSortAmount(sorts);
		
		return stats;
	}
}
